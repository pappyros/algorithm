#ifndef SHAPE_MANAGER_H
#define SHAPE_MANAGER_H

#include <vector>
#include <memory>
#include "WinShape.h"

class ShapeManager
{
public:
	virtual ~ShapeManager();
	void add(shared_ptr<WinShape> shape); // shape �߰�
	shared_ptr<WinShape> get(int n); // return n��° Shape
	void draw(HDC hdc);
	WinShape* findShape(int x, int y);

protected:
	std::vector<shared_ptr<WinShape>> m_Shapes;
};
#endif