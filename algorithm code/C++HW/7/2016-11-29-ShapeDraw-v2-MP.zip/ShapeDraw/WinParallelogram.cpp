#include <iostream>
#include "WinRectangle.h"
#include "WinParallelogram.h"

WinParallelogram::WinParallelogram() : shapelib::Rectangle()
{
}

WinParallelogram::WinParallelogram(int x1, int y1, int x2, int y2, int width, int height)
{
}

void WinParallelogram::draw(HDC hdc) const
{
}

bool WinParallelogram::isInside(int x, int y) const
{
}

void WinParallelogram::move(int x, int y)
{
}

