#include "ShapeManager.h"

ShapeManager::~ShapeManager()
{
}

void ShapeManager::add(shared_ptr<WinShape> s)
{
	m_Shapes.push_back(s);
}

shared_ptr<WinShape> ShapeManager::get(int index)
{
	return m_Shapes.at(index);
}

void ShapeManager::draw(HDC hdc) 
{
}

WinShape* ShapeManager::findShape(int x, int y)
{
	return NULL;
}