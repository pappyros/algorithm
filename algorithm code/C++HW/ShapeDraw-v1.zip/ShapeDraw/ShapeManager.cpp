#include "ShapeManager.h"

ShapeManager::~ShapeManager()
{

}

void ShapeManager::add(WinShape* s)
{
}

WinShape* ShapeManager::get(int index) 
{
	return NULL;
}

void ShapeManager::draw(HDC hdc) 
{
}
